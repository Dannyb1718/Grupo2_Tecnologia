from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
#==================== Configuración del Servidor ====================
usuario_bd = 'root'
password_bd = 'Ayla_1421'
servidor_bd = 'localhost'
puerto_bd = '3306'
nombre_bd = 'carnavales'

#==================== Configurar base de datos ====================
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{usuario_bd}:{password_bd}@{servidor_bd}:{puerto_bd}/{nombre_bd}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False

#==================== Inicializar DB y Marshmallow ====================
db = SQLAlchemy(app)
ma = Marshmallow(app)

#=========================== Creacion Tablas =============================

class Cajita(db.Model):  
    __tablename__ = "cajita" 

    id_cajita = db.Column(db.Integer, primary_key=True)  # Se genera el campo que contiene nuestra llave primaria
    titulo = db.Column(db.String(255))  # Se genera campo nombre
    descripcion = db.Column(db.String(4000))
    # Se genera campo descripción
    imagen_url= db.Column(db.String(255))

    def __init__(self, titulo, descripcion, imagen_url):  # Se crea función constructora de la clase
        # self: Es una referencia a la instancia actual de una clase. Es el primer parámetro en los métodos de una clase
        self.titulo = titulo
        self.descripcion = descripcion
        self.imagen_url = imagen_url

#=========================== CATEGORIAS =============================
# Esquema Tabla Categoria
class CajitaSchema(ma.SQLAlchemyAutoSchema):  
    # Se genera el esquema, es decir, cuando se hace una consulta el esquema es lo que me identifica los datos
    class Meta:  # Subclase que realiza la configuración del esquema
        model = Cajita
        load_instance = True

# Esquemas para cuando es un dato y otro para varios
cajita_schema = CajitaSchema()  # Esquema de respuesta cuando es un elemento
cajitas_schema = CajitaSchema(many=True)  # Esquema de respuesta cuando son todos los elementos

#=========================== GET =============================

@app.route('/cajita', methods=['GET'])  # Se especifica la URL que debe ser ingresada para ejecutar la función que se encuentra abajo
def get_cajitas():
    all_cajitas = Cajita.query.all()  # Función que permite traer todos los registros de la consulta
    result = cajitas_schema.dump(all_cajitas)  # Genera un diccionario con los elementos traídos de la consulta (organiza la información)
    return jsonify(result)  # Estructura la respuesta en formato JSON

#=========================== GET (ID) =============================

@app.route('/cajita/<id>', methods=['GET'])  # Se especifica la URL con una variable id
def get_cajita_id(id):
    una_cajita = Cajita.query.get(id)  # Función que permite realizar la consulta por la llave primaria, trae un elemento
    return cajita_schema.jsonify(una_cajita)  # Estructura la respuesta en formato JSON
#=========================== POST =============================

@app.route('/cajita', methods=['POST'])  # Se especifica la URL que debe ser ingresada para ejecutar la función
def insert_cajita():
    data = request.get_json(force=True)  # Al ser por método POST, se trae la información que se especificó en el cliente (por ejemplo, desde Postman)

    titulo = data['titulo']  # Variables que se traen en el request
    descripcion = data['descripcion']
    imagen_url = data['imagen_url']

    nueva_cajita = Cajita(titulo, descripcion, imagen_url)  # Se genera objeto tipo Categoria para ser almacenado en la tabla

    db.session.add(nueva_cajita)  # Se especifica el tipo de sentencia en SQL (INSERT INTO)
    db.session.commit()  # Se ejecuta la sentencia

    return cajita_schema.jsonify(nueva_cajita)  # Se presenta la información que se almacenó en formato JSON
#=========================== PUT =============================

@app.route('/cajita/<id>', methods=['PUT'])  # Se especifica la URL que debe ser ingresada para ejecutar la función
def update_categoria(id):  # Se recibe la variable que se especificó en el route
    data = request.get_json(force=True)  # Al ser por método PUT, se trae la información enviada por el cliente (ej: Postman)

    actualizar_cajita = Cajita.query.get(id)  # Consulta por la llave primaria (trae un elemento)

    titulo = data['titulo']  # Variables que se traen en el request
    descripcion = data['descripcion']
    imagen_url = data['imagen_url']

    actualizar_cajita.titulo = titulo  # Se actualiza la información del elemento
    actualizar_cajita.descripcion = descripcion
    actualizar_cajita.imagen_url = imagen_url

    db.session.commit()  # Se ejecuta la sentencia

    return cajita_schema.jsonify(actualizar_cajita)  # Se presenta la información actualizada en formato JSON
#=========================== DELETE =============================

@app.route('/cajita/<id>', methods=['DELETE'])  # Se especifica la URL que debe ser ingresada para ejecutar la función
def delete_cajita(id):  # Se recibe la variable que se especificó en el route
    eliminar_cajita = Cajita.query.get(id)  # Consulta por la llave primaria, trae un elemento

    db.session.delete(eliminar_cajita)  # Sentencia SQL para eliminar el registro (DELETE)
    db.session.commit()  # Se ejecuta la sentencia

    return cajita_schema.jsonify(eliminar_cajita)  # Se presenta la información eliminada en formato JSON

#==================== Ejecutar servidor ====================
if __name__ == '__main__':
    with app.app_context():
        db.create_all() 
        app.run(debug=True)